<?php

@include 'config.php';



if(isset($_POST['submit'])){

   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $pass = $_POST['password'];
   $cpass = $_POST['cpassword'];
   $user_type = $_POST['user_type'];
  
   echo $user_type;
   
   if($user_type == 'student'){
      $select = " SELECT * FROM student WHERE email = '$email' && password = '$pass' ";

   }else{
      $select = " SELECT * FROM teacher WHERE email = '$email' && password = '$pass' ";

   }

   
   $result = mysqli_query($conn, $select);

   

   if(mysqli_num_rows($result) > 0){

      $error[] = 'user already exist!';
      echo 'user already exist!';
      echo mysqli_num_rows($result);
   }else{

      if($pass != $cpass){
         $error[] = 'password not matched!';
      }else if($user_type == 'student'){
         $roll = $_POST['roll'];
         $regis = $_POST['regis'];

         $insert = "INSERT INTO student(name, email, roll, registration_no, password) VALUES('$name','$email', '$roll', '$regis', '$pass')";
         mysqli_query($conn, $insert);
         header('location:login_form.php');
      } else if($user_type == 'teacher'){
         $id = $_POST['teacher_id'];
         $section_id = $_POST['section_id'];


         $insert = "INSERT INTO teacher(name, email,teacher_id, adviced_series, password) VALUES('$name','$email', '$id', '$section_id', '$pass')";
         mysqli_query($conn, $insert);
         header('location:login_form.php');
      }
   }

};


?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>register form</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="./css/style.css">
   <style>
     
   </style>

</head>
<body>
  
<div class="form-container">

   <form action="" method="post" id="reg_form">
      <h3>register now</h3>
      <?php
      if(isset($error)){
         foreach($error as $error){
            echo '<span class="error-msg">'.$error.'</span>';
         };
      };
      ?>
      <input type="text" name="name" required placeholder="Enter your name">
      <input type="email" name="email" required placeholder="Enter your email" class="stu">

      <div id="stu" class="hide">
      <input type="text" name='roll'  placeholder="enter your roll" >
      <input type="text" name='regis'  placeholder="enter your registraion no">
      </div>

      <div id="teach" class="hide">
      <input type="text" name='teacher_id'  placeholder="enter your teacher id">
      <input type="text" name='section_id'  placeholder="Course adviced series & section">
      </div>
     
      <input type="password" name="password" required placeholder="enter your password">
      <input type="password" name="cpassword" required placeholder="confirm your password">
      <select name="user_type" onchange="shift(event)">
         <option value="student" selected>student</option>
         <option value="teacher">teacher</option>
      </select>
      <input type="submit" name="submit" value="register now" class="form-btn">
      <h3><p>already have an account? <a href="login_form.php">login now</a></p></h3>
   </form>

</div>
      <script>
        
         filterForm('student');

         function shift(e){
         
            filterForm(e.target.value);
         }
         
         function filterForm(x){
         var stu = document.getElementById('stu');
         var teach = document.getElementById('teach');
            if(x=='student'){
              stu.classList.remove('hide');
              teach.classList.add('hide');
            }else{
              stu.classList.add('hide');
              teach.classList.remove('hide');
            }
         }
      </script>
</body>
</html>