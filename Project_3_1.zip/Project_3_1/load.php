<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam Registration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #FDFEFE;
            background-image: url('CSE_ruet.jpg');
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color:#FDFEFE;
            border-radius: 5px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        }

        h1 {
            text-align: center;
            color:#196F3D;
        }

        form {
            margin-top: 20px;
            background-color:#FDFEFE;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="checkbox"] {
            margin-right: 5px;
        }

        input[type="submit"] {
            background-color: #007BFF;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .btn-group {
            text-align: center;
            margin-top: 20px;
        }

        .btn {
            text-decoration: none;
            background-color: #007BFF;
            color: #fff;
            padding: 10px 20px;
            margin: 0 10px;
            border-radius: 4px;
            display: inline-block;
        }

        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php
        $rol = $_POST['roll'];
        $sem = $_POST['sem'];

        $conn = mysqli_connect('localhost:3306', 'root', '', '3_1project');
        if ($conn->connect_error) {
            die('Connection failed: ' . $conn->connect_error);
        }
        
        foreach ($_POST['chked'] as $value) {
            $sql = "INSERT INTO exam_reg (roll, course_code, sem) VALUES ('$rol', '$value', '$sem')";
            if ($conn->query($sql) === False) {
                echo "Sorry! Your Registration has been failed" . $value;
            }
        }
        echo '<h1>Registration successful</h1>';
        ?>
        <div class="btn-group">
            <a href="process_form.php" class="btn">Exam Registration</a>
            <a href="user_page.php" class="btn">Main Page</a>
            <a href="course_regis.php" class="btn">Course Registration</a>
            <a href="welcome.php" class="btn">Logout</a>
        </div>
    </div>
</body>
</html>
