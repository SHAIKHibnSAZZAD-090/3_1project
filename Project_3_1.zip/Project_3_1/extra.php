<!DOCTYPE html>
<html>
<head>
<title>Student Registration Form</title>
</head>
<body>
<form action="submit.php" method="post">
  <h2>Student Registration Form</h2>
  <input type="text" name="student_name" placeholder="Student Name">
  <input type="text" name="roll_number" placeholder="Roll Number">
  <input type="text" name="session" placeholder="Session">
  <input type="number" name="previously_earned_credit" placeholder="Previously Earned Credit">
  <select id="semester" name="sem">
        <option value="1">1st Semester</option>
        <option value="2">2nd Semester</option>
        <option value="3">3rd Semester</option>
        <option value="4">4th Semester</option>
        <option value="5">5th Semester</option>
        <option value="6">6th Semester</option>
        <option value="7">7th Semester</option>
        <option value="8">8th Semester</option>
      </select>
      <div id="course-list" class="course-list">
        <!-- Semester 1 Courses -->
        <div id="s1">
        <h3 >Semester 1 Courses:</h3>
            <label><input type="checkbox" name="course[]" value="CSE 1100"> CSE 1100</label><br>
            <label><input type="checkbox" name="course[]" value="CSE 1101"> CSE 1101</label><br>
            <label><input type="checkbox" name="course[]" value="CSE 1102"> CSE 1102</label><br>
            <label><input type="checkbox" name="course[]" value="EEE 1151"> EEE 1151</label><br>
            <label><input type="checkbox" name="course[]" value="EEE 1152"> EEE 1152</label><br>
            <label><input type="checkbox" name="course[]" value="Math 1113"> Math 1113</label><br>
            <label><input type="checkbox" name="course[]" value="Hum 1113"> Hum 1113</label><br>
            <label><input type="checkbox" name="course[]" value="Hum 1114"> Hum 1114</label><br>
            <label><input type="checkbox" name="course[]" value="Chem 1113"> Chem 1113</label><br>
            <label><input type="checkbox" name="course[]" value="Chem 1114"> Chem 1114</label><br>
        </div>
            <!-- Semester 2 Courses -->
            <div id="s2">
            <h3 >Semester 2 Courses:</h3>
            <label><input type="checkbox" name="course[]" value="CSE 1200"> CSE 1200</label><br>
            <label><input type="checkbox" name="course[]" value="CSE 1201"> CSE 1201</label><br>
            <label><input type="checkbox" name="course[]" value="CSE 1202"> CSE 1202</label><br>
            <label><input type="checkbox" name="course[]" value="CSE 1203"> CSE 1203</label><br>
            <label><input type="checkbox" name="course[]" value="CSE 1204"> CSE 1204</label><br>
            <label><input type="checkbox" name="course[]" value="Math 1213"> Math 1213</label><br>
            <label><input type="checkbox" name="course[]" value="Hum 1213"> Hum 1213</label><br>
            <label><input type="checkbox" name="course[]" value="Phy 1213"> Phy 1213</label><br>
            <label><input type="checkbox" name="course[]" value="Phy 1214"> Phy 1214</label><br>
            </div>
        </div>
        <button onclick="myFunction()">Click Me</button>
        <script>
          
    function changeStyle(){
        var element = document.getElementById("s2");
        element.style.display = "none";
    }
    </script>
  <input type="submit" value="Submit">
</form>
</body>
</html>