<?php

$conn = mysqli_connect('localhost:3306','root','','3_1project');

?>