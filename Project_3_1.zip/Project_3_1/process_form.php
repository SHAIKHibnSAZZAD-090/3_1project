
<!DOCTYPE html>
<html>
<head>
  <title>Exam Form</title>
  <link rel="stylesheet" href="style.css">
  <style>
 
    body {
      font-family: Arial, sans-serif;
      background-color: #dee6e8;
      margin: 0;
      padding: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 60vh;
    }
    form {
    max-width: 400px; 
    margin: 50px auto;
    padding: 40px; 
    background-color: #32b3a8;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}


    input[type="text"] {
      width: 100%;
      padding: 10px;
      margin-bottom: 10px;
      border: 1px solid #ccc;
      border-radius: 4px;
    }

    label {
      display: block;
      font-weight: bold;
    }

    input[type="radio"] {
      margin-right: 5px;
    }

    table {
      width: 100%;
      margin-bottom: 20px;
      border-collapse: collapse;
    }

    th, td {
      padding: 10px;
      text-align: left;
      border-bottom: 1px solid #ccc;
    }

    .submit-btn {
      background-color: #007bff;
      color: #fff;
      border: none;
      padding: 10px 20px;
      border-radius: 4px;
      cursor: pointer;
      margin-top: 10px;
      display: block;
      margin-left: auto;
      margin-right: auto;
    }

    .submit-btn:hover {
      background-color: #0056b3;
    }
  </style>
</head>
<body>
<form action="req_course.php" method="post" > <!-- Modify action attribute to point to your PHP processing script -->
    <h2><p style="text-align:center">Fill the first Page of Exam Form</p></h2>
   
    <input type="text" name="roll" placeholder="Your roll number">
    <input type="text" name="semester" placeholder="semester">
    <label>Student Type:</label>
    <input type="radio" name="student_type" value="regular"> Regular student
    <input type="radio" name="student_type" value="irregular"> Irregular student
    <b><button type="submit" class="submit-btn">Submit</button></b>
    <b><a href="user_page.php" class="btn">Back to User Page</a></b>
  </form>
</body>
</html>
