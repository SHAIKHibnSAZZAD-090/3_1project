<?php

$servername = "localhost";
$username = "root";
$password = "";
$a="login";
// Create connection
foreach ($_POST as $key => $value) 
{
    echo $key." ".$value."<br>";
}
//$conn = new mysqli($servername, $username, $password,$a);
//$un="'".$_POST["sem"]."'";
// $mob="'".$_POST["mobile"]."'";
// $fn="'".$_POST["fname"]."'";
// $pass="'".$_POST["pass"]."'";
// $gen="'".$_POST["gender"]."'";
// $mail="'".$_POST["mail"]."'";
//$fao="ddd";
//echo $un;
// if ($conn->connect_error) {
//   die("Connection failed: Contact MD Toufique" );
//   exit();
// }

// $sql = "INSERT INTO log (username,fullname,mail,mobile,gender,password)
// VALUES ($un, $fn, $mail,$mob,$gen,$pass)";

// if ($conn->query($sql) === TRUE) {
//   echo "<br><h1>New record created successfully</h1>";
// } else {
//   //echo "Error: " . $sql . "<br>" . $conn->error;
//   echo "<br><h1>Username already exist. please change the username.</h1>";
// }


// mysqli_close($conn);
?> 