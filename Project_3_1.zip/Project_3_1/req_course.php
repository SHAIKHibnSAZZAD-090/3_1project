
<?php

$roll = $_POST['roll'];
$sem = $_POST['semester'];



?>
<!DOCTYPE html>
<html>
<head>
  <title>Exam Form</title>
  <link rel="stylesheet" href="style.css">
  <style>
    /* Add your CSS styles here */
    /* Example styles: */
    body {
      font-family: Arial, sans-serif;
      background-color: #dee6e8;
      margin: 0;
      padding: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 130vh;
    }
    form {
    max-width: 500px; /* Increase the max-width to your desired value */
    margin: 50px auto;
    padding: 40px; /* Increase the padding to your desired value */
    background-color: #32b3a8;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

   
    input[type="text"] {
      width: 100%;
      padding: 10px;
      margin-bottom: 10px;
      border: 1px solid #ccc;
      border-radius: 4px;
    }

    label {
      display: block;
      font-weight: bold;
    }

    input[type="radio"] {
      margin-right: 5px;
    }

    table {
      width: 100%;
      margin-bottom: 20px;
      border-collapse: collapse;
    }

    th, td {
      padding: 10px;
      text-align: left;
      border-bottom: 1px solid #ccc;
    }

    .submit-btn {
      background-color: #007bff;
      color: #fff;
      border: none;
      padding: 10px 20px;
      border-radius: 4px;
      cursor: pointer;
      margin-top: 10px;
      display: block;
      margin-left: auto;
      margin-right: auto;
    }

    .submit-btn:hover {
      background-color: #0056b3;
    }
  </style>
</head>
<body>
<form action="load.php" method="post" > <!-- Modify action attribute to point to your PHP processing script -->
    <h2><p style="text-align:center">List of the courses for the Exam</p></h2>
    <?php
     echo '<input type="text" disabled value='.$roll.'>';
     echo '<input type="text" disabled  value='.$sem.'>';
    echo '<input type="text" hidden name="roll" value='.$roll.'>';
    echo '<input type="text" hidden name="sem" value='.$sem.'>';
    ?>
    
      <?php
      $conn = mysqli_connect('localhost:3306','root','','3_1project');
      if ($conn->connect_error) {
          die('Connection failed: ' . $conn->connect_error);
      }
    $sql = "SELECT * FROM course where sem=$sem ";

        $result = $conn->query($sql);
        mysqli_query($conn, $sql);

        while ($row = mysqli_fetch_assoc($result)){
            $courseCode = $row["course_code"];
            $courseTitle = $row["course_title"];
            echo '<input type="checkbox" name="chked[]" value="' . $courseCode . '"> ' . $courseCode . '<p>' . $courseTitle . '</p>';
        }
    ?>
    <input  type="submit" value="submit">
    <b><p style="color: #ccc;"><a href="process_form.php" class="button">Back to previous page</a></p></b>
    <h4><p style="color:white;font-family:roman">Note:For optional courses contact to your adviser teacher</p></h4>
    </table>
    
  </form>
</body>
</html>
