<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam Registration Table</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: burlywood;
        }
    </style>
</head>
<body>
<h2><p style="color: blue; text-align: center;">Information about exam registered students</p></h2>

    <?php
    $servername = 'localhost:3306';
    $username = 'root';
    $password = '';
    $database = '3_1project';

    // Create a connection to the database
    $conn = new mysqli($servername, $username, $password, $database);

    // Check the connection
    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    // SQL query to select all records from the exam_reg table
    $sql = "SELECT * FROM exam_reg ORDER BY sem ASC";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo '<table>';
        echo '<tr><th>Roll</th><th>Registered Course Code</th><th>Semester No</th></tr>';
        while ($row = $result->fetch_assoc()) {
            $r = $row["roll"];
            $cc = $row["course_code"];
            $s = $row["sem"];
            echo '<tr><td>' . $r . '</td><td>' . $cc . '</td><td>' . $s . '</td></tr>';
        }
        echo '</table>';
    } else {
        echo 'No records found.';
    }

    // Close the database connection
    $conn->close();
    ?>
     <h3><a href="admin_page.php" class="btn">Back to Admin Page</a></h3>
</body>
</html>
